//
//  myTableViewCell.swift
//  json_parse
//
//  Created by SREEHARI MOHAN on 27/10/23.
//

import UIKit

class myTableViewCell: UITableViewCell {

    @IBOutlet weak var label1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
